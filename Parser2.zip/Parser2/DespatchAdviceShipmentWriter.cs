﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using EdiFabric.Core.Model.Edi.Edifact;
using EdiFabric.Templates.EdifactD97A;

namespace Parser2
{
    public static class DespatchAdviceShipmentWriter
    {


        public static TSDESADV BuildDespatchAdvice(string controlNumber, TSORDERS ord)
        {
            var result = new TSDESADV();

            result.UNH = new UNH();
            result.UNH.MessageReferenceNumber_01 = controlNumber.PadLeft(14, '0');
            result.UNH.MessageIdentifier_02 = new S009();
            result.UNH.MessageIdentifier_02.MessageType_01 = "DESADV";
            result.UNH.MessageIdentifier_02.MessageVersionNumber_02 = "D";
            result.UNH.MessageIdentifier_02.MessageReleaseNumber_03 = "97A";
            result.UNH.MessageIdentifier_02.ControllingAgencyCoded_04 = "UN";

            result.BGM = new BGM();
            result.BGM.DOCUMENTMESSAGENAME_01 = new C002();
            result.BGM.DOCUMENTMESSAGENAME_01.Documentmessagenamecoded_01 = "630";
            result.BGM.Messagefunctioncoded_03 = "8";

            result.DTM = new List<DTM>
            {
                new DTM
                {
                    DATETIMEPERIOD_01 = new C507
                    {
                        Datetimeperiodqualifier_01 = "111",
                        Datetimeperiod_02 = DateTime.UtcNow.ToString("yyMMddHHmmss"),
                        Datetimeperiodformatqualifier_03 = "202"
                    }
                }
            };

            result.MEA = new List<MEA>
            {
                new MEA
                {
                    Measurementpurposequalifier_01 = "AAI",
                    MEASUREMENTDETAILS_02 = new C502
                    {
                        Propertymeasuredcoded_01 = "AAD"
                    },
                    VALUERANGE_03 = new C174
                    {
                        Measureunitqualifier_01 = "273",
                        Measurementvalue_02 = "KG"
                    }
                },
                new MEA
                {
                    Measurementpurposequalifier_01 = "WOL",
                    MEASUREMENTDETAILS_02 = new C502
                    {
                        Propertymeasuredcoded_01 = "AAW"
                    },
                    VALUERANGE_03 = new C174
                    {
                        Measureunitqualifier_01 = "2.621",
                        Measurementvalue_02 = "M3"
                    }
                }
            };

            result.RFFLoop = new List<Loop_RFF_DESADV>
            {

            };

            result.CPSLoop = new List<Loop_CPS_DESADV>
            {
                new Loop_CPS_DESADV
                {
                    CPS = new CPS
                    {
                        Hierarchicalidnumber_01 = "1"
                    },
                    PACLoop = new List<Loop_PAC_DESADV>
                    {
                        new Loop_PAC_DESADV
                        {
                            PAC = new PAC
                            {
                                Numberofpackages_01 = "1"
                            }
                        }
                    },
                    LINLoop = ord.LINLoop.Select(ln =>
                        new Loop_LIN_DESADV
                        {
                            MEA = new List<MEA>
                            {
                                new MEA
                                {
                                    Measurementpurposequalifier_01 = "AAI",
                                    MEASUREMENTDETAILS_02 = new C502
                                    {
                                        Propertymeasuredcoded_01 = "AAD"
                                    },
                                    VALUERANGE_03 = new C174
                                    {
                                        Measureunitqualifier_01 = "273",
                                        Measurementvalue_02 = "KG"
                                    }
                                },
                                new MEA
                                {
                                    Measurementpurposequalifier_01 = "WOL",
                                    MEASUREMENTDETAILS_02 = new C502
                                    {
                                        Propertymeasuredcoded_01 = "AAW"
                                    },
                                    VALUERANGE_03 = new C174
                                    {
                                        Measureunitqualifier_01 = "2.621",
                                        Measurementvalue_02 = "M3"
                                    }
                                }
                            },
                            PCILoop = new List<Loop_PCI_DESADV_2>
                            {
                                new Loop_PCI_DESADV_2
                                {
                                    PCI = new PCI
                                    {
                                        Markinginstructionscoded_01 = "ZZZ",

                                    }
                                }
                            }
                        }
                    ).ToList()
                }
            };

            return result;
        }
    }
}