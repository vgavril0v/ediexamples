﻿using System;
using System.IO;
using System.Linq;
using EdiFabric.Core.Model.Edi;
using EdiFabric.Framework;
using EdiFabric.Framework.Readers;
using EdiFabric.Framework.Writers;
using EdiFabric.Templates.EdifactD97A;

namespace Parser2
{
    public static class DespatchAdviceGRWriter
    {
        public static void WriteEdiFactGRResponse(string sourceEdiPath, string responseFolderPath)
        {
            foreach (var file in Directory.EnumerateFiles(sourceEdiPath).Select(f => new FileInfo(f)))
            {
                using (EdifactReader reader =
                    new EdifactReader(new FileStream(Path.Combine(sourceEdiPath), FileMode.Open)))
                {
                    var ediItems = reader.ReadToEnd().ToList();
                    foreach (var item in ediItems.Where(item => item is TSDESADV || item is TSORDERS))
                    {
                        WriteEdiFactGRResponse(item,
                            Path.Combine(responseFolderPath, Path.GetFileNameWithoutExtension(file.Name) + "_GR.txt"));
                    }
                }
            }
        }

        public static void WriteEdiFactGRResponse(IEdiItem ediItem, string responseFilePath)
        {
            var controlNumber = new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds().ToString();
            var transaction = ediItem is TSORDERS ?
                DespatchAdviceGRBuilder.BuildDespatchAdvice(controlNumber, (TSORDERS)ediItem) :
                DespatchAdviceGRBuilder.BuildDespatchAdvice(controlNumber, (TSDESADV)ediItem);

            using (var stream = File.Create(responseFilePath))
            {
                using (var writer = new EdifactWriter(stream))
                {
                    writer.Write(Separators.Edifact.ToUna());
                    writer.Write(EDIFactSegmentBuilders.BuildUnb("1"));
                    writer.Write(transaction);
                }

            }
        }
    }
}